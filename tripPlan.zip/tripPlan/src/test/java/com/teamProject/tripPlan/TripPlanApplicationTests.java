package com.teamProject.tripPlan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TripPlanApplicationTests {

	@Test
	void contextLoads() {
	}

}
