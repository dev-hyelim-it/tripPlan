package com.teamProject.tripPlan.entity;

import lombok.Getter;

@Getter
public enum UserRole {
    // 사용자 역할 설정
    ROLE_USER,
    ROLE_ADMIN
}
