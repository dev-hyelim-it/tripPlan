package com.teamProject.tripPlan.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TravelDatesDTO {
    private String startDate;
    private String endDate;
}
