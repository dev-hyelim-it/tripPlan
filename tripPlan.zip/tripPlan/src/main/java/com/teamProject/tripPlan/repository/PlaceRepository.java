package com.teamProject.tripPlan.repository;

import com.teamProject.tripPlan.entity.Place;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PlaceRepository extends JpaRepository<Place, Long> {
}
