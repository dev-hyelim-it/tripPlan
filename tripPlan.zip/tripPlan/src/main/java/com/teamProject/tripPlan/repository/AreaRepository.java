package com.teamProject.tripPlan.repository;

import com.teamProject.tripPlan.entity.Area;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AreaRepository extends JpaRepository<Area, String> {
}

