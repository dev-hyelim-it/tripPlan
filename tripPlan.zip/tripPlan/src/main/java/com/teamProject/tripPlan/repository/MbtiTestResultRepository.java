package com.teamProject.tripPlan.repository;

import com.teamProject.tripPlan.entity.MbtiTestResult;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MbtiTestResultRepository extends JpaRepository<MbtiTestResult, Long> {
}
