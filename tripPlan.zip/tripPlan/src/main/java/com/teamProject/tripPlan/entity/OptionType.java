package com.teamProject.tripPlan.entity;

public enum OptionType {
    HEALING,
    ACTIVITY,
    NATURE,
    CITY
}
