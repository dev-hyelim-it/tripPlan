package com.teamProject.tripPlan.dao;

import jakarta.persistence.EntityManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class AnswerOptionsDAO {

    @Autowired
    EntityManager em;



}
