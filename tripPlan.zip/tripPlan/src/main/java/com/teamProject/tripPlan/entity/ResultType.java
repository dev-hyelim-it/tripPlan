package com.teamProject.tripPlan.entity;

public enum ResultType {
    HN,
    HC,
    AN,
    AC
}
